# RG Construções — Android v2.0

Aplicativo administrativo Android com banco de dados SQLite local.

## Funcionalidades
- Dashboard com caixa, contas a receber, obras e equipe.
- Cadastro/edição de obras, contrato, pago, saldo e status.
- Registro de recebimentos por obra.
- Cadastro/edição de trabalhadores.
- Registro de vales por trabalhador e reflexo no caixa.
- Caixa: entradas, saídas, saldo e histórico.
- Orçamentos: cliente, serviço, valor, descrição e status.
- Comprovantes em PDF.
- Dados persistentes no aparelho através de SQLite.
- Dados iniciais das 5 obras e 7 trabalhadores cadastrados.

## Gerar APK
Abrir a pasta `RGConstrucoesAPK` no Android Studio com SDK Android 35 instalado.
Depois: **Build > Build APK(s)**.

APK esperado: `app/build/outputs/apk/debug/app-debug.apk`
