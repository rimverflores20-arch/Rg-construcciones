package com.rgconstrucoes.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;

public class MainActivity extends Activity {
    private DB db;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(Color.rgb(247,248,250));

        TextView title = new TextView(this);
        title.setText("RG CONSTRUÇÕES"); title.setTextSize(26); title.setTextColor(Color.rgb(20,48,82));
        title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,18); root.addView(title);

        status = card("Painel\nCaixa: R$ 0,00\nA receber: R$ 0,00\nObras: 0\nTrabalhadores: 0"); root.addView(status);
        addButton(root, "OBRAS", "Cadastro de obras, contratos e recebimentos");
        addButton(root, "TRABALHADORES", "Equipe, diárias e vales");
        addButton(root, "CAIXA", "Entradas, saídas e saldo");
        addButton(root, "ORÇAMENTOS", "Criar e consultar orçamentos");
        addButton(root, "COMPROVANTES", "Gerar comprovantes em PDF");
        setContentView(root);
    }
    private TextView card(String s) { TextView t=new TextView(this); t.setText(s); t.setTextSize(18); t.setTextColor(Color.DKGRAY); t.setBackgroundColor(Color.WHITE); t.setPadding(22,22,22,22); return t; }
    private void addButton(LinearLayout root,String name,String desc){ Button b=new Button(this); b.setText(name+"\n"+desc); b.setAllCaps(false); b.setOnClickListener(v -> status.setText(name+"\nMódulo preparado para cadastro e consulta.")); root.addView(b); }
    static class DB extends android.database.sqlite.SQLiteOpenHelper {
        DB(Context c){super(c,"rg_construcoes.db",null,1);} 
        public void onCreate(SQLiteDatabase d){ d.execSQL("CREATE TABLE obras(id INTEGER PRIMARY KEY AUTOINCREMENT, cliente TEXT, endereco TEXT, contrato REAL, pago REAL, status TEXT)"); d.execSQL("CREATE TABLE trabalhadores(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, funcao TEXT, valor REAL)"); d.execSQL("CREATE TABLE caixa(id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT, valor REAL, descricao TEXT, data TEXT)"); d.execSQL("CREATE TABLE vales(id INTEGER PRIMARY KEY AUTOINCREMENT, trabalhador_id INTEGER, valor REAL, motivo TEXT, data TEXT)"); d.execSQL("CREATE TABLE orcamentos(id INTEGER PRIMARY KEY AUTOINCREMENT, cliente TEXT, servico TEXT, valor REAL, descricao TEXT, status TEXT)"); }
        public void onUpgrade(SQLiteDatabase d,int o,int n){d.execSQL("DROP TABLE IF EXISTS obras");d.execSQL("DROP TABLE IF EXISTS trabalhadores");d.execSQL("DROP TABLE IF EXISTS caixa");d.execSQL("DROP TABLE IF EXISTS vales");d.execSQL("DROP TABLE IF EXISTS orcamentos");onCreate(d);}
    }
}
