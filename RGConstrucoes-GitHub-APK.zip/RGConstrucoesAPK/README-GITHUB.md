# RG Construções — compilar pelo celular

1. Crie um repositório no GitHub.
2. Envie todo o conteúdo desta pasta mantendo `.github/workflows/build-apk.yml`.
3. Abra a aba **Actions**.
4. Escolha **Build RG Construções APK** e toque em **Run workflow**.
5. Quando terminar, abra a execução e baixe o artefato **RG-Construcoes-APK**.
6. Dentro dele estará `app-debug.apk`.

O GitHub Actions fornece os runners e ferramentas de build para executar o Gradle na nuvem. Consulte a documentação oficial do GitHub sobre Actions e Gradle.
